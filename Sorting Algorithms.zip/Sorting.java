import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.PriorityQueue;

/**
 * Your implementation of various sorting algorithms.
 *
 * @author Gino Doumit
 * @version 1.0
 * @userid gdoumit3
 * @GTID 903665016
 *
 * Collaborators: LIST ALL COLLABORATORS YOU WORKED WITH HERE
 *
 * Resources: LIST ALL NON-COURSE RESOURCES YOU CONSULTED HERE
 */
public class Sorting {

    /**
     * Helper method for swapping
     *
     * @param arr the array where the swapping is occurring
     * @param i1 the first index of the element being swapped
     * @param i2 the second index of the element being swapped
     * @param <T> the data type of the array
     */
    public static <T> void swapHelper(T[] arr, int i1, int i2) {
        if (i1 == i2) {
            return;
        } else {
            Object temp = arr[i1];
            arr[i1] = arr[i2];
            arr[i2] = (T) temp;
        }
    }

    /**
     * Implement selection sort.
     *
     * It should be:
     * in-place
     * unstable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n^2)
     *
     * And a best case running time of:
     * O(n^2)
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void selectionSort(T[] arr, Comparator<T> comparator) {
        //Exception:
        if (arr == null) {
            throw new IllegalArgumentException("The array you entered is null! Cannot sort a null array.");
        }
        if (comparator == null) {
            throw new IllegalArgumentException("The comparator you entered is null! Cannot use a null comparator.");
        }

        int maxIndex;

        for (int n = arr.length - 1; n >= 1; n--) {
            maxIndex = 0;
            for (int i = 1; i <= n; i++) {
                if (comparator.compare(arr[i], arr[maxIndex]) > 0) {
                    maxIndex = i;
                }
            }
            swapHelper(arr, maxIndex, n);
        }
    }

    /**
     * Implement cocktail sort.
     *
     * It should be:
     * in-place
     * stable
     * adaptive
     *
     * Have a worst case running time of:
     * O(n^2)
     *
     * And a best case running time of:
     * O(n)
     *
     * NOTE: See pdf for last swapped optimization for cocktail sort. You
     * MUST implement cocktail sort with this optimization
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void cocktailSort(T[] arr, Comparator<T> comparator) {
        //Exception:
        if (arr == null) {
            throw new IllegalArgumentException("The array you entered is null! Cannot sort a null array.");
        }
        if (comparator == null) {
            throw new IllegalArgumentException("The comparator you entered is null! Cannot use a null comparator.");
        }

        boolean swapsMade = true;
        int startIndex = 0;
        int endIndex = arr.length - 1;
        int temp;
        while (swapsMade) {
            swapsMade = false;
            temp = endIndex;
            for (int i = startIndex; i < temp; i++) {
                if (comparator.compare(arr[i], arr[i + 1]) > 0) {
                    swapHelper(arr, i, i + 1);
                    swapsMade = true;
                    endIndex = i;
                }
            }
            temp = startIndex;
            if (swapsMade) {
                swapsMade = false;
                for (int i = endIndex; i > temp; i--) {
                    if (comparator.compare(arr[i - 1], arr[i]) > 0) {
                        swapHelper(arr, i - 1, i);
                        swapsMade = true;
                        startIndex = i;
                    }
                }
            }
        }
    }

    /**
     * Implement merge sort.
     *
     * It should be:
     * out-of-place
     * stable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n log n)
     *
     * And a best case running time of:
     * O(n log n)
     *
     * You can create more arrays to run merge sort, but at the end, everything
     * should be merged back into the original T[] which was passed in.
     *
     * When splitting the array, if there is an odd number of elements, put the
     * extra data on the right side.
     *
     * Hint: If two data are equal when merging, think about which subarray
     * you should pull from first
     *
     * @param <T>        data type to sort
     * @param arr        the array to be sorted
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void mergeSort(T[] arr, Comparator<T> comparator) {
        //Exception:
        if (arr == null) {
            throw new IllegalArgumentException("The array you entered is null! Cannot sort a null array.");
        }
        if (comparator == null) {
            throw new IllegalArgumentException("The comparator you entered is null! Cannot use a null comparator.");
        }
        if (arr.length == 1) {
            return;
        }
        int length = arr.length;
        int midIndex = length / 2;
        Object[] left = new Object[midIndex];
        for (int i = 0; i < midIndex; i++) {
            left[i] = arr[i];
        }
        Object[] right = new Object[length - midIndex];
        for (int i = 0; i < (length - midIndex); i++) {
            right[i] = arr[i + midIndex];
        }

        mergeSort((T[]) left, comparator);
        mergeSort((T[]) right, comparator);

        int i = 0;
        int j = 0;

        while (i < left.length && j < right.length) {
            if (comparator.compare((T) left[i], (T) right[j]) <= 0) {
                arr[i + j] = (T) left[i];
                i++;
            } else {
                arr[i + j] = (T) right[j];
                j++;
            }
        }
        while (i < left.length) {
            arr[i + j] = (T) left[i];
            i++;
        }
        while (j < right.length) {
            arr[i + j] = (T) right[j];
            j++;
        }

    }

    /**
     * Implement quick sort.
     *
     * Use the provided random object to select your pivots. For example if you
     * need a pivot between a (inclusive) and b (exclusive) where b > a, use
     * the following code:
     *
     * int pivotIndex = rand.nextInt(b - a) + a;
     *
     * If your recursion uses an inclusive b instead of an exclusive one,
     * the formula changes by adding 1 to the nextInt() call:
     *
     * int pivotIndex = rand.nextInt(b - a + 1) + a;
     *
     * It should be:
     * in-place
     * unstable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n^2)
     *
     * And a best case running time of:
     * O(n log n)
     *
     * Make sure you code the algorithm as you have been taught it in class.
     * There are several versions of this algorithm and you may not receive
     * credit if you do not use the one we have taught you!
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @param rand       the Random object used to select pivots
     * @throws java.lang.IllegalArgumentException if the array or comparator or
     *                                            rand is null
     */
    public static <T> void quickSort(T[] arr, Comparator<T> comparator,
                                     Random rand) {
        //Exception:
        if (arr == null) {
            throw new IllegalArgumentException("The array you entered is null! Cannot sort a null array.");
        }
        if (comparator == null) {
            throw new IllegalArgumentException("The comparator you entered is null! Cannot use a null comparator.");
        }
        if (rand == null) {
            throw new IllegalArgumentException("The comparator you entered is null! Cannot use a null random gen.");
        }
        quickSortHelper(arr, 0, arr.length - 1, comparator, rand);
    }

    /**
     * Recursive quicksort helper function
     *
     * @param arr the array which will be sorted
     * @param start the first index of the sub-array
     * @param end the last index of the sub-array
     * @param comparator the comparator we are working with
     * @param rand the random which we are working with
     * @param <T> the data type we are working with
     */

    public static <T> void quickSortHelper(T[] arr, int start, int end, Comparator<T> comparator, Random rand) {
        if ((end - start) < 1) {
            return;
        }
        int pivotIndex = rand.nextInt(end - start + 1) + start;
        Object pivotVal = arr[pivotIndex];
        swapHelper(arr, start, pivotIndex);

        int i = start + 1;
        int j = end;

        while (i <= j) {
            while (i <= j && comparator.compare(arr[i], (T) pivotVal) <= 0) {
                i++;
            }
            while (i <= j && comparator.compare(arr[j], (T) pivotVal) >= 0) {
                j--;
            }
            if (i <= j) {
                swapHelper(arr, i, j);
                i++;
                j--;
            }
        }
        swapHelper(arr, start, j);
        quickSortHelper(arr, start, j - 1, comparator, rand);
        quickSortHelper(arr, j + 1, end, comparator, rand);
    }

    /**
     * Implement LSD (least significant digit) radix sort.
     *
     * Make sure you code the algorithm as you have been taught it in class.
     * There are several versions of this algorithm and you may not get full
     * credit if you do not implement the one we have taught you!
     *
     * Remember you CANNOT convert the ints to strings at any point in your
     * code! Doing so may result in a 0 for the implementation.
     *
     * It should be:
     * out-of-place
     * stable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(kn)
     *
     * And a best case running time of:
     * O(kn)
     *
     * You are allowed to make an initial O(n) passthrough of the array to
     * determine the number of iterations you need. The number of iterations
     * can be determined using the number with the largest magnitude.
     *
     * At no point should you find yourself needing a way to exponentiate a
     * number; any such method would be non-O(1). Think about how how you can
     * get each power of BASE naturally and efficiently as the algorithm
     * progresses through each digit.
     *
     * Refer to the PDF for more information on LSD Radix Sort.
     *
     * You may use ArrayList or LinkedList if you wish, but it may only be
     * used inside radix sort and any radix sort helpers. Do NOT use these
     * classes with other sorts. However, be sure the List implementation you
     * choose allows for stability while being as efficient as possible.
     *
     * Do NOT use anything from the Math class except Math.abs().
     *
     * @param arr the array to be sorted
     * @throws java.lang.IllegalArgumentException if the array is null
     */
    public static void lsdRadixSort(int[] arr) {
        //Exception:
        if (arr == null) {
            throw new IllegalArgumentException("The array you entered is null! Cannot sort null.");
        }
        int longest = 0;
        int counter;
        int check;
        int divisor;
        for (int i = 0; i < arr.length; i++) {
            counter = 1;
            check = 1;
            divisor = 10;
            while (check != 0) {
                check = arr[i] / divisor;
                if (check == 0) {
                    break;
                }
                counter++;
                divisor = divisor * 10;
            }
            if (counter > longest) {
                longest = counter;
            }
        }

        LinkedList<Integer>[] buckets = new LinkedList[19];
        divisor = 1;
        int digit;
        for (int i = 0; i < longest; i++) {
            for (int j = 0; j < arr.length; j++) {
                digit = (arr[j] / divisor) % 10;
                digit = digit + 9;
                if (buckets[digit] == null) {
                    buckets[digit] = new LinkedList<Integer>();
                }
                buckets[digit].addLast(arr[j]);
            }
            divisor = divisor * 10;
            int idx = 0;
            for (LinkedList<Integer> linkedlist: buckets) {
                if (linkedlist == null) {
                    linkedlist = new LinkedList<Integer>();
                }
                for (Integer element: linkedlist) {
                    arr[idx++] = element;
                }
                linkedlist.clear();
            }
        }

    }

    /**
     * Implement heap sort.
     *
     * It should be:
     * out-of-place
     * unstable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n log n)
     *
     * And a best case running time of:
     * O(n log n)
     *
     * Use java.util.PriorityQueue as the heap. Note that in this
     * PriorityQueue implementation, elements are removed from smallest
     * element to largest element.
     *
     * Initialize the PriorityQueue using its build heap constructor (look at
     * the different constructors of java.util.PriorityQueue).
     *
     * Return an int array with a capacity equal to the size of the list. The
     * returned array should have the elements in the list in sorted order.
     *
     * @param data the data to sort
     * @return the array with length equal to the size of the input list that
     * holds the elements from the list is sorted order
     * @throws java.lang.IllegalArgumentException if the data is null
     */
    public static int[] heapSort(List<Integer> data) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>(data);
        int[] array = new int[data.size()];
        for (int i = 0; i < array.length; i++) {
            array[i] = minHeap.remove();
        }
        return array;

    }
}
