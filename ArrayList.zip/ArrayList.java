import java.util.NoSuchElementException;

/**
 * Your implementation of an ArrayList.
 *
 * @author Gino Doumit
 * @version 1.0
 * @userid gdoumit3
 * @GTID 903665016
 *
 * Collaborators: LIST ALL COLLABORATORS YOU WORKED WITH HERE
 *
 * Resources: LIST ALL NON-COURSE RESOURCES YOU CONSULTED HERE
 */
public class ArrayList<T> {

    /**
     * The initial capacity of the ArrayList.
     *
     * DO NOT MODIFY THIS VARIABLE!
     */
    public static final int INITIAL_CAPACITY = 9;

    // Do not add new instance variables or modify existing ones.
    private T[] backingArray;
    private int size;

    /**
     * Constructs a new ArrayList.
     *
     * Java does not allow for regular generic array creation, so you will have
     * to cast an Object[] to a T[] to get the generic typing.
     */
    public ArrayList() {
        backingArray = (T[]) (new Object[INITIAL_CAPACITY]);
        size = 0;
    }

    /**
     * Adds the element to the specified index.
     *
     * Remember that this add may require elements to be shifted.
     *
     * Must be amortized O(1) for index size and O(n) for all other cases.
     *
     * @param index the index at which to add the new element
     * @param data  the data to add at the specified index
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index > size
     * @throws java.lang.IllegalArgumentException  if data is null
     */
    public void addAtIndex(int index, T data) {
        //Exceptions
        if (index < 0) {
            throw new IndexOutOfBoundsException("The index is negative!");
        }
        if (index > size) {
            throw new IndexOutOfBoundsException("The index is greater than the list size!");
        }
        if (null == data) {
            throw new IllegalArgumentException("The data you entered is null!");
        }

        //Adding the element to the array:

        //Case where the capacity of backingArray should be doubled
        if (size + 1 == backingArray.length) {
            //I will do the whole operation in one loop instead of looping through the list many times

            //Step 1: Double the size of the backingArray
            int newArrayLength = backingArray.length * 2;
            Object[] newArray = new Object[newArrayLength];

            //Step 2: Copy all elements before index
            for (int i = 0; i < index; i++) {
                newArray[i] = backingArray[i];
            }

            //Step 3: Add the element at the new index
            newArray[index] = data;

            //Step 4: Add the elements after the index
            for (int i = index; i < backingArray.length; i++) {
                newArray[i + 1] = backingArray[i];
            }

            //Step 5: Setting backingArray = newArray:
            backingArray = (T[]) newArray;
        } /*Case where the size is less than the capacity */ else {

            //Shifting all the elements after the index to the right:
            for (int i = size - 1; i > index - 1; i--) {
                backingArray[i + 1] = backingArray[i];
            }

            //Adding the new element:
            backingArray[index] = data;

        }

        //Incrementing size
        size++;


    }

    /**
     * Adds the element to the front of the list.
     *
     * Remember that this add may require elements to be shifted.
     *
     * Must be O(n).
     *
     * @param data the data to add to the front of the list
     * @throws java.lang.IllegalArgumentException if data is null
     */
    @SuppressWarnings("checkstyle:RightCurly")
    public void addToFront(T data) {
        //Exception
        if (null == data) {
            throw new IllegalArgumentException("The data you entered is null!");
        }
        //Case where the capacity of backingArray should be doubled
        if (size + 1 == backingArray.length) {
            //I will do the whole operation in one loop instead of looping through the list many times

            //Step 1: Double the size of the array
            int newArrayLength = backingArray.length * 2;
            Object[] newArray = new Object[newArrayLength];

            //Step 2: Add the element to the front
            newArray[0] = data;

            //Step 3: Copying the rest of the elements shifted
            for (int i = 0; i < backingArray.length; i++) {
                newArray[i + 1] = backingArray[i];
            }

            //Step 4: Setting backingArray = newArray
            backingArray = (T[]) newArray;

        } /* Case where size is less than capacity */        else {
            //Shifting all of the elements to the right:
            for (int i = size; i >= 0; i--) {
                backingArray[i + 1] = backingArray[i];
            }

            //Adding the new element to the front
            backingArray[0] = data;

        }
        size++;

    }

    /**
     * Adds the element to the back of the list.
     *
     * Must be amortized O(1).
     *
     * @param data the data to add to the back of the list
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToBack(T data) {
        //Exception
        if (null == data) {
            throw new IllegalArgumentException("The data you entered is null!");
        }
        //Checking if the new size of backingArray is equal to the capacity
        if (size + 1 == backingArray.length) {
            //newArrayLength should be doubled
            int newArrayLength = backingArray.length * 2;

            //Creating the new array:
            Object[] newArray = new Object[newArrayLength];

            //Copying the elements from the old array to newArray:
            for (int i = 0; i < backingArray.length; i++) {
                newArray[i] = backingArray[i];
            }

            backingArray = (T[]) newArray;
        }

        backingArray[size] = data;
        size++;
    }

    /**
     * Removes and returns the element at the specified index.
     *
     * Remember that this remove may require elements to be shifted.
     *
     * Must be O(1) for index size - 1 and O(n) for all other cases.
     *
     * @param index the index of the element to remove
     * @return the data formerly located at the specified index
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index >= size
     */
    public T removeAtIndex(int index) {
        //Exceptions:
        if (index < 0) {
            throw new IndexOutOfBoundsException("Index is less than zero!");
        }
        if (index >= size) {
            throw new IndexOutOfBoundsException("Index is greater than the ArrayList size!");
        }

        if (index == size - 1) {
            //Same as if we were removing from the back
            return removeFromBack();
        } else {
            //Saving the removed element:
            Object removedElement = backingArray[index];

            //Shifting the sublist starting from index to the left:
            for (int i = index; i < size; i++) {
                backingArray[i] = backingArray[i + 1];
            }
            //Removing the last element in backingArray:
            backingArray[size - 1] = null;

            //Decrementing size:
            size--;

            //Returning the removed element:
            return (T) removedElement;
        }
    }

    /**
     * Removes and returns the first element of the list.
     *
     * Remember that this remove may require elements to be shifted.
     *
     * Must be O(n).
     *
     * @return the data formerly located at the front of the list
     * @throws java.util.NoSuchElementException if the list is empty
     */
    public T removeFromFront() {
        //Exception:
        if (isEmpty()) {
            throw new NoSuchElementException("There is nothing to delete! The list is empty.");
        }
        //Saving the removed element:
        Object removedElement = backingArray[0];

        //Shifting the list to the left, effectively deleting the first element:
        for (int i = 0; i < size - 1; i++) {
            backingArray[i] = backingArray[i + 1];
        }

        //Removing the last elemenent in backingArray:
        backingArray[size - 1] = null;

        //Decrementing size:
        size--;

        //Returning the removed element:
        return (T) removedElement;
    }

    /**
     * Removes and returns the last element of the list.
     *
     * Must be O(1).
     *
     * @return the data formerly located at the back of the list
     * @throws java.util.NoSuchElementException if the list is empty
     */
    public T removeFromBack() {
        //Exception:
        if (isEmpty()) {
            throw new NoSuchElementException("Nothing to remove! The list is empty.");
        }
        //Saving the element which will be removed:
        Object removedElement = backingArray[size - 1];

        //Removing the element from backingArray:
        backingArray[size - 1] = null;

        //Decrementing size:
        size--;

        //Returning the removed element:
        return (T) removedElement;
    }

    /**
     * Returns the element at the specified index.
     *
     * Must be O(1).
     *
     * @param index the index of the element to get
     * @return the data stored at the index in the list
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index >= size
     */
    public T get(int index) {
        //Exceptions:
        if (index < 0) {
            throw new IndexOutOfBoundsException("The index is negative!");
        }
        if (index > size) {
            throw new IndexOutOfBoundsException("The index is greater than the list size!");
        }
        //Returning the value
        return backingArray[index];
    }

    /**
     * Returns whether or not the list is empty.
     *
     * Must be O(1).
     *
     * @return true if empty, false otherwise
     */
    public boolean isEmpty() {
        //If the size is 0, then the list is empty
        return size == 0;
    }

    /**
     * Clears the list.
     *
     * Resets the backing array to a new array of the initial capacity and
     * resets the size.
     *
     * Must be O(1).
     */
    public void clear() {

        //Resetting the backing array to a new array with the intial capacity
        backingArray = (T[]) (new Object[INITIAL_CAPACITY]);

        //Resetting the size
        size = 0;
    }

    /**
     * Returns the backing array of the list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the backing array of the list
     */
    public T[] getBackingArray() {
        // DO NOT MODIFY THIS METHOD!
        return backingArray;
    }

    /**
     * Returns the size of the list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the size of the list
     */
    public int size() {
        // DO NOT MODIFY THIS METHOD!
        return size;
    }

}
