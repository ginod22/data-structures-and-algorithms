import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.LinkedList;

/**
 * Your implementation of a BST.
 *
 * @author Gino Doumit
 * @version 1.0
 * @userid gdoumit3
 * @GTID 903665016
 *
 * Collaborators: LIST ALL COLLABORATORS YOU WORKED WITH HERE
 *
 * Resources: LIST ALL NON-COURSE RESOURCES YOU CONSULTED HERE
 */
public class BST<T extends Comparable<? super T>> {

    // Do not add new instance variables or modify existing ones.
    private BSTNode<T> root;
    private int size;

    /**
     * Constructs a new BST.
     *
     * This constructor should initialize an empty BST.
     *
     * Since instance variables are initialized to their default values, there
     * is no need to do anything for this constructor.
     */
    public BST() {
        // DO NOT IMPLEMENT THIS CONSTRUCTOR!
    }

    /**
     * Constructs a new BST.
     *
     * This constructor should initialize the BST with the data in the
     * Collection. The data should be added in the same order it is in the
     * Collection.
     *
     * Hint: Not all Collections are indexeable like Lists, so a regular for loop
     * will not work here. However, all Collections are Iterable, so what type
     * of loop would work?
     *
     * @param data the data to add to the tree
     * @throws java.lang.IllegalArgumentException if data or any element in data
     *                                            is null
     */
    public BST(Collection<T> data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException(
                    "The collection is null! A BST cannot be created from a null collection!");
        }
        for (T dataIt: data) {
            //Adding every element to the BST
            //NB: this function already throws an IllegalArgumentException if the data is null
            add(dataIt);
        }

    }

    /**
     * Adds the element to the tree.
     *
     * The data becomes a leaf in the tree.
     *
     * Traverse the tree to find the appropriate location. If the data is
     * already in the tree, then nothing should be done (the duplicate
     * shouldn't get added, and size should not be incremented).
     *
     * Must be O(log n) for a balanced tree and O(n) for worst case.
     * 
     * This method must be implemented recursively.
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void add(T data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is null! Cannot add null to the BST.");
        }
        //Edge case:
        if (root == null) {
            root = new BSTNode<>(data);
        } else {
            //Calling the helper function
            addHelper(data, root);
        }
        //Incrementing the size
        size++;

    }

    /**
     * Recursive helper function for the add function
     *
     * @param data data to be added.
     * @param node node that is being checked
     * @return returns the node which was deleted
     * @throws java.lang.IllegalArgumentException if data is already in the BST
     */

    private BSTNode<T> addHelper(T data, BSTNode<T> node) {
        //Uses pointer reinforcement to add the new node
        if (node == null) {
            //Base Case:
            return new BSTNode<>(data);
        } else if (data.compareTo(node.getData()) > 0) {
            //Go right if the data to be entered is greater than the node's data
            node.setRight(addHelper(data, node.getRight()));
        } else if (data.compareTo(node.getData()) < 0) {
            //Go left if the data to be entered is less than the node's data
            node.setLeft(addHelper(data, node.getLeft()));
        } else if (data.equals(node.getData())) {
            //Decrement the size of the BST since we are adding a duplicate
            //In the main add function, the size is always incremented
            size--;
        }
        return node;
    }

    /**
     * Removes and returns the element from the tree matching the given
     * parameter.
     *
     * There are 3 cases to consider:
     * 1: The node containing the data is a leaf (no children). In this case,
     * simply remove it.
     * 2: The node containing the data has one child. In this case, simply
     * replace it with its child.
     * 3: The node containing the data has 2 children. Use the predecessor to
     * replace the data. You MUST use recursion to find and remove the
     * predecessor (you will likely need an additional helper method to
     * handle this case efficiently).
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the tree.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Must be O(log n) for a balanced tree and O(n) for worst case.
     * 
     * This method must be implemented recursively.
     *
     * @param data the data to remove
     * @return the data that was removed
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not in the tree
     */
    public T remove(T data) {
        //Exceptions:
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is null! Cannot add null to the BST.");
        }
        if (size == 0) {
            throw new NoSuchElementException("The BST is empty! There is nothing to remove!");
        }
        //Initializing where we will store the removed data:
        Object removedData;

        //Edge case:
        if (size == 1) {
            //Exception for the edge case
            if (!data.equals(root.getData())) {
                throw new NoSuchElementException("The data is not in the tree!");
            }

            //Saving the removed data
            removedData = root.getData();

            //Reinitializing the root
            root = null;
        } else {
            //Creating the dummy node where we will store the removed data
            BSTNode<T> dummy = new BSTNode<>(null);

            //Calling the helper function
            removeHelper(data, root, dummy);

            //Saving the removed data
            removedData = dummy.getData();

            //Exception:
            if (removedData == null) {
                throw new NoSuchElementException("The data is not in the tree!");
            }
        }
        //Decrementing the size and returning the removed element
        size--;
        return (T) removedData;
    }

    /**
     * Recursive helper function for the remove method
     *
     * @param data the data to be removed
     * @param node the node where we are looking for the data
     * @param dummy the data that was removed from the BST
     * @return the node where the data is located
     */
    private BSTNode<T> removeHelper(T data, BSTNode<T> node, BSTNode<T> dummy) {
        //Using pointer reinforcement to remove the node
        if (node == null) {
            return null;
        } else if (data.equals(node.getData())) {
            //Base cases:

            if (node.getRight() == null && node.getLeft() == null) {
                //Case 1: Node has no children

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the node from the BST
                return null;
            } else if (node.getRight() != null && node.getLeft() == null) {
                //Case 2-a: Node has 1 child on the right

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the node from the BST
                return node.getRight();
            } else if (node.getLeft() != null && node.getRight() == null) {
                //Case 2-b: Node has 1 child on the left

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the node from the BST
                return node.getLeft();
            } else {
                //Getting the data from the predecessor
                Object newData = getPredecessor(node.getLeft());

                //Removing the node containing the predecessor from the tree
                removeHelper((T) newData, node, dummy);

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the data from the BST (by setting its data to that of the predecessor)
                node.setData((T) newData);
                return node;
            }
        } else if (data.compareTo(node.getData()) > 0) {
            //Go right if the data to be entered is greater than the node's data
            node.setRight(removeHelper(data, node.getRight(), dummy));
        } else if (data.compareTo(node.getData()) < 0) {
            //Go left if the data to be entered is less than the node's data
            node.setLeft(removeHelper(data, node.getLeft(), dummy));
        }
        return node;
    }

    /**
     * Helper function for finding the predecessor of a node
     *
     * @param node the left child of the node whose predecessor is meant to be found
     * @return the data of the predecessor of the inputted node's parent
     */
    private T getPredecessor(BSTNode<T> node) {
        //Keeps going right until you find the right-most node in the subtree
        Object predecessor = node.getData();
        while (node.getRight() != null) {
            predecessor = node.getRight().getData();
            node = node.getRight();
        }
        return (T) predecessor;
    }

    /**
     * Recursive helper function for get.
     *
     * @param data the data that is being looked for in the list.
     * @param node the node where the node where the data is being looked for
     * @return the node where the data is found if the tree contains the data, null if not
     */
    private BSTNode<T> getHelper(T data, BSTNode<T> node) {
        //Performs recursive binary search to find the node with the given data

        if (node == null) {
            return null;
        } else if (data.compareTo(node.getData()) > 0) {
            return getHelper(data, node.getRight());
        } else if (data.compareTo(node.getData()) < 0) {
            return getHelper(data, node.getLeft());
        } else {
            return node;
        }

    }

    /**
     * Returns the element from the tree matching the given parameter.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Must be O(log n) for a balanced tree and O(n) for worst case.
     * 
     * This method must be implemented recursively.
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the tree.
     *
     * @param data the data to search for in the tree
     * @return the data in the tree equal to the parameter
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not in the tree
     */
    public T get(T data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException("The data entered is null! Cannot search for null in the tree.");
        }
        //Getting the node with the data
        BSTNode<T> node = getHelper(data, root);

        //Exception:
        if (node == null) {
            throw new NoSuchElementException("The data is not found in the list!");
        } else {
            return node.getData();
        }
    }

    /**
     * Recursive helper function for contains
     *
     * @param data the data that is being looked for in the list.
     * @param node the node where the node where the data is being looked for
     * @return true if the parameter is contained within the tree, false
     * otherwise
     */
    private boolean containsHelper(T data, BSTNode<T> node) {
        //Performs recursive binary search to find if the BST contains the data
        if (node == null) {
            return false;
        } else if (data.compareTo(node.getData()) > 0) {
            return containsHelper(data, node.getRight());
        } else if (data.compareTo(node.getData()) < 0) {
            return containsHelper(data, node.getLeft());
        } else {
            return true;
        }
    }

    /**
     * Returns whether or not data matching the given parameter is contained
     * within the tree.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Must be O(log n) for a balanced tree and O(n) for worst case.
     * 
     * This method must be implemented recursively.
     *
     * @param data the data to search for in the tree.
     * @return true if the parameter is contained within the tree, false
     * otherwise
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public boolean contains(T data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is nulL! Cannot search for null in the BST.");
        }
        //Call the helper function
        return containsHelper(data, root);
    }

    /**
     * Generate a pre-order traversal of the tree.
     *
     * Must be O(n).
     *
     * This method must be implemented recursively.
     *
     * @return the preorder traversal of the tree
     */
    public List<T> preorder() {
        List<T> list = new ArrayList<>();
        preorderHelper(root, list);
        return list;
    }

    /**
     * Recursive helper function for preorder
     *
     * @param node the node where we are looking.
     * @param list the preorder traversal of the tree.
     */
    private void preorderHelper(BSTNode<T> node, List<T> list) {
        if (node == null) {
            return;
        }
        list.add(node.getData());
        preorderHelper(node.getLeft(), list);
        preorderHelper(node.getRight(), list);
    }

    /**
     * Generate a in-order traversal of the tree.
     *
     * Must be O(n).
     * 
     * This method must be implemented recursively.
     *
     * @return the inorder traversal of the tree
     */
    public List<T> inorder() {
        List<T> list = new ArrayList<>();
        inorderHelper(root, list);
        return list;
    }

    /**
     * Recursive helper function for inorder
     *
     * @param node the node where we are looking.
     * @param list the preorder traversal of the tree.
     */
    private void inorderHelper(BSTNode<T> node, List<T> list) {
        if (node == null) {
            return;
        }
        inorderHelper(node.getLeft(), list);
        list.add(node.getData());
        inorderHelper(node.getRight(), list);
    }

    /**
     * Generate a post-order traversal of the tree.
     *
     * Must be O(n).
     * 
     * This method must be implemented recursively.
     *
     * @return the postorder traversal of the tree
     */
    public List<T> postorder() {
        List<T> list = new ArrayList<>();
        postorderHelper(root, list);
        return list;
    }

    /**
     * Recursive helper function for postorder
     *
     * @param node the node where we are looking.
     * @param list the preorder traversal of the tree.
     */
    private void postorderHelper(BSTNode<T> node, List<T> list) {
        if (node == null) {
            return;
        }
        postorderHelper(node.getLeft(), list);
        postorderHelper(node.getRight(), list);
        list.add(node.getData());
    }

    /**
     * Generate a level-order traversal of the tree.
     *
     * This does not need to be done recursively.
     *
     * Hint: You will need to use a queue of nodes. Think about what initial
     * node you should add to the queue and what loop / loop conditions you
     * should use.
     *
     * Must be O(n).
     *
     * @return the level order traversal of the tree
     */
    public List<T> levelorder() {
        List<T> list = new ArrayList<>();
        Queue<BSTNode<T>> queue = new LinkedList<>();
        queue.add(root);
        BSTNode<T> curr;
        while (!queue.isEmpty()) {
            curr = queue.remove();
            if (curr != null) {
                list.add(curr.getData());
                if (curr.getLeft() != null) {
                    queue.add(curr.getLeft());
                }
                if (curr.getRight() != null) {
                    queue.add(curr.getRight());
                }
            }
        }
        return list;
    }

    /**
     * Returns the height of the root of the tree.
     *
     * A node's height is defined as max(left.height, right.height) + 1. A
     * leaf node has a height of 0 and a null child should be -1.
     *
     * Must be O(n).
     * 
     * This method must be implemented recursively.
     *
     * @return the height of the root of the tree, -1 if the tree is empty
     */
    public int height() {
        //Edge case:
        if (size == 0) {
            return -1;
        }
        return heightHelper(root);
    }

    /**
     * Recursive helper function for the height function
     *
     * @param node the node whose height is being calculated
     * @return the integer height of the inputted node
     */
    private int heightHelper(BSTNode<T> node) {
        //Base cases:
        if (node == null || ((node.getLeft() == null) && (node.getRight() == null))) {
            return 0;
        }
        //Recursive calls:

        //Finding the height of the left child
        int lh = heightHelper(node.getLeft());
        //Finding the height of the right child
        int rh = heightHelper(node.getRight());
        //returns the greater value of the two height values
        if (lh > rh) {
            return lh + 1;
        } else {
            return rh + 1;
        }

    }

    /**
     * Clears the tree.
     *
     * Clears all data and resets the size.
     *
     * Must be O(1).
     */
    public void clear() {
        //Reintializes the BST
        root = null;
        size = 0;
    }

    /**
     * This method checks whether a binary tree meets the criteria for being
     * a binary search tree.
     *
     * This method is a static method that takes in a BSTNode called
     * {@code treeRoot}, which is the root of the tree that you should check.
     *
     * You may assume that the tree passed in is a proper binary tree; that is,
     * there are no loops in the tree, the parent-child relationship is
     * correct, that there are no duplicates, and that every parent has at
     * most 2 children. So, what you will have to check is that the order
     * property of a BST is still satisfied.
     *
     * Should run in O(n). However, you should stop the check as soon as you
     * find evidence that the tree is not a BST rather than checking the rest
     * of the tree.
     * 
     * This method must be implemented recursively.
     *
     * @param <T> the generic typing
     * @param treeRoot the root of the binary tree to check
     * @return true if the binary tree is a BST, false otherwise
     */
    public static <T extends Comparable<? super T>> boolean isBST(BSTNode<T> treeRoot) {
        //Creating the dummy node from which we will read if the tree is a BST or not
        BSTNode<T> check = new BSTNode<>(null);

        //Calling the helper function
        new BST<T>().isBSTHelper(treeRoot, new BSTNode<>(null), check);

        //Returning whether the tree is a BST or not
        return (check.getData() == null);
    }

    /**
     * Recursive helper function for isBST
     *
     * @param curr the node being compared to prev
     * @param prev the node being compared to curr
     * @param check node which will be used to check for isBST
     */
    private void isBSTHelper(BSTNode<T> curr, BSTNode<T> prev, BSTNode<T> check) {
        //Traverses through the list in an inorder fashion
        //If the node is less than the predecessor, then the tree is not a BST
        //If it is not a BST, then the check node's data is set to the first value which makes the tree not a BST
        //To directly terminate the search, a base case is added where if check's data is not null, we directly return

        //Base cases:
        if (curr == null || check.getData() != null) {
            return;
        }
        //Go left in the tree
        isBSTHelper(curr.getLeft(), prev, check);

        //Perform the comparison (inorder)
        //NB: the first condition is added since, without it, the first node being compared to nothing
        if ((prev.getData() != null) && (curr.getData().compareTo(prev.getData()) < 0)) {
            check.setData(curr.getData());
        }
        //Setting the prev node's data to the current node's value, for later comparison
        prev.setData(curr.getData());

        //Go right in the tree
        isBSTHelper(curr.getRight(), prev, check);
    }

    /**
     * Returns the root of the tree.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the root of the tree
     */
    public BSTNode<T> getRoot() {
        // DO NOT MODIFY THIS METHOD!
        return root;
    }

    /**
     * Returns the size of the tree.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the size of the tree
     */
    public int size() {
        // DO NOT MODIFY THIS METHOD!
        return size;
    }
}
