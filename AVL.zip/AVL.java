import java.util.Collection;
import java.util.NoSuchElementException;

/**
 * Your implementation of an AVL.
 *
 * @author Gino Doumit
 * @version 1.0
 * @userid gdoumit3
 * @GTID 903665016
 *
 * Collaborators: LIST ALL COLLABORATORS YOU WORKED WITH HERE
 *
 * Resources: LIST ALL NON-COURSE RESOURCES YOU CONSULTED HERE
 */
public class AVL<T extends Comparable<? super T>> {

    // Do not add new instance variables or modify existing ones.
    private AVLNode<T> root;
    private int size;

    /**
     * Constructs a new AVL.
     *
     * This constructor should initialize an empty AVL.
     *
     * Since instance variables are initialized to their default values, there
     * is no need to do anything for this constructor.
     */
    public AVL() {
        // DO NOT IMPLEMENT THIS CONSTRUCTOR!
    }

    /**
     * Constructs a new AVL.
     *
     * This constructor should initialize the AVL with the data in the
     * Collection. The data should be added in the same order it is in the
     * Collection.
     *
     * @param data the data to add to the tree
     * @throws java.lang.IllegalArgumentException if data or any element in data
     *                                            is null
     */
    public AVL(Collection<T> data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException(
                    "The collection is null! AVLs cannot be created from a null collection!");
        }
        for (T dataIt: data) {
            //Adding every element to the AVL
            //NB: this function already throws an IllegalArgumentException if the data is null
            add(dataIt);
        }
    }

    /**
     * Helper method for a right rotation
     *
     * @param node the node on which we are performing the rotation
     * @return the new root of the subtree
     */
    private AVLNode<T> rightRotate(AVLNode<T> node) {
        AVLNode<T> x = node.getLeft();
        if (root == node) {
            root = x;
        }
        AVLNode<T> temp = x.getRight();

        x.setRight(node);
        node.setLeft(temp);


        node.setHeight(Math.max(nodeHeight(node.getLeft()), nodeHeight(node.getRight())) + 1);
        x.setHeight(Math.max(nodeHeight(x.getLeft()), nodeHeight(x.getRight())) + 1);

        x.setBalanceFactor(nodeBalance(x));
        node.setBalanceFactor(nodeBalance(node));

        return x;
    }

    /**
     * Helper method for a left rotation
     *
     * @param node the node on which we are performing the rotation
     * @return the new root of the subtree
     */
    private AVLNode<T> leftRotate(AVLNode<T> node) {
        AVLNode<T> x = node.getRight();
        AVLNode<T> temp = x.getLeft();

        x.setLeft(node);
        node.setRight(temp);

        if (root == node) {
            root = x;
        }

        node.setHeight(Math.max(nodeHeight(node.getLeft()), nodeHeight(node.getRight())) + 1);
        x.setHeight(Math.max(nodeHeight(x.getLeft()), nodeHeight(x.getRight())) + 1);

        x.setBalanceFactor(nodeBalance(x));
        node.setBalanceFactor(nodeBalance(node));


        return x;
    }

    /**
     * Helper method for finding the height of a node
     *
     * @param node the node whose height is being found
     * @return the height of the node
     */

    private int nodeHeight(AVLNode<T> node) {
        if (node == null) {
            return -1;
        }
        return node.getHeight();
    }

    /**
     * Helper method for finding the balance factor of a node
     *
     * @param node the node whose height is being found
     * @return the height of the node
     */

    private int nodeBalance(AVLNode<T> node) {
        if (node == null) {
            return 0;
        }
        return nodeHeight(node.getLeft()) - nodeHeight(node.getRight());
    }



    /**
     * Adds the element to the tree.
     *
     * Start by adding it as a leaf like in a regular BST and then rotate the
     * tree as necessary.
     *
     * If the data is already in the tree, then nothing should be done (the
     * duplicate shouldn't get added, and size should not be incremented).
     *
     * Remember to recalculate heights and balance factors while going back
     * up the tree after adding the element, making sure to rebalance if
     * necessary.
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void add(T data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is null! Cannot add null to the AVL.");
        }
        //Edge case:
        if (root == null) {
            root = new AVLNode<>(data);
            root.setHeight(0);
            root.setBalanceFactor(0);
        } else {
            //Calling the helper function
            root = addHelper(data, root);
        }
        //Incrementing the size
        size++;
    }

    /**
     * Recursive helper function for the add function
     *
     * @param data data to be added.
     * @param node node that is being checked
     * @return returns the node which was deleted
     * @throws java.lang.IllegalArgumentException if data is already in the AVL
     */

    private AVLNode<T> addHelper(T data, AVLNode<T> node) {
        //Uses pointer reinforcement to add the new node
        if (node == null) {
            //Base Case:
            return new AVLNode<>(data);
        } else if (data.compareTo(node.getData()) > 0) {
            //Go right if the data to be entered is greater than the node's data
            node.setRight(addHelper(data, node.getRight()));
        } else if (data.compareTo(node.getData()) < 0) {
            //Go left if the data to be entered is less than the node's data
            node.setLeft(addHelper(data, node.getLeft()));
        } else if (data.equals(node.getData())) {
            //Decrement the size of the AVL since we are adding a duplicate
            //In the main add function, the size is always incremented
            size--;
        }

        //Do the rotations if needed

        node.setHeight(Math.max(nodeHeight(node.getLeft()), nodeHeight(node.getRight())) + 1);

        node.setBalanceFactor(nodeBalance(node));

        if (node.getBalanceFactor() == -2 && node.getRight().getBalanceFactor() <= 0) {
            return leftRotate(node);
        } else if (node.getBalanceFactor() == 2 && node.getLeft().getBalanceFactor() >= 0) {
            return rightRotate(node);
        } else if (node.getBalanceFactor() == 2 && node.getLeft().getBalanceFactor() < 0) {
            node.setLeft(leftRotate(node.getLeft()));
            return rightRotate(node);
        } else if (node.getBalanceFactor() == -2 && node.getRight().getBalanceFactor() > 0) {
            node.setRight(rightRotate(node.getRight()));
            return leftRotate(node);
        }

        return node;
    }

    /**
     * Removes and returns the element from the tree matching the given
     * parameter.
     *
     * There are 3 cases to consider:
     * 1: The node containing the data is a leaf (no children). In this case,
     * simply remove it.
     * 2: The node containing the data has one child. In this case, simply
     * replace it with its child.
     * 3: The node containing the data has 2 children. Use the successor to
     * replace the data, NOT predecessor. As a reminder, rotations can occur
     * after removing the successor node.
     *
     * Remember to recalculate heights and balance factors while going back
     * up the tree after removing the element, making sure to rebalance if
     * necessary.
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the tree.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * @param data the data to remove
     * @return the data that was removed
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not found
     */
    public T remove(T data) {
        //Exceptions:
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is null! Cannot add null to the AVL.");
        }
        if (size == 0) {
            throw new NoSuchElementException("The AVL is empty! There is nothing to remove!");
        }
        //Initializing where we will store the removed data:
        Object removedData;

        //Edge case:
        if (size == 1) {
            //Exception for the edge case
            if (!data.equals(root.getData())) {
                throw new NoSuchElementException("The data is not in the tree!");
            }

            //Saving the removed data
            removedData = root.getData();

            //Reinitializing the root
            root = null;
        } else {
            //Creating the dummy node where we will store the removed data
            AVLNode<T> dummy = new AVLNode<>(null);

            //Calling the helper function
            root = removeHelper(data, root, dummy);

            //Saving the removed data
            removedData = dummy.getData();

            //Exception:
            if (removedData == null) {
                throw new NoSuchElementException("The data is not in the tree!");
            }
        }
        //Decrementing the size and returning the removed element
        size--;
        return (T) removedData;
    }

    /**
     * Recursive helper function for the remove method
     *
     * @param data the data to be removed
     * @param node the node where we are looking for the data
     * @param dummy the data that was removed from the AVL
     * @return the node where the data is located
     */
    private AVLNode<T> removeHelper(T data, AVLNode<T> node, AVLNode<T> dummy) {
        //Using pointer reinforcement to remove the node
        if (node == null) {
            return null;
        } else if (data.equals(node.getData())) {
            //Base cases:

            if (node.getRight() == null && node.getLeft() == null) {
                //Case 1: Node has no children

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the node from the AVL
                return null;
            } else if (node.getRight() != null && node.getLeft() == null) {
                //Case 2-a: Node has 1 child on the right

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the node from the AVL
                return node.getRight();
            } else if (node.getLeft() != null && node.getRight() == null) {
                //Case 2-b: Node has 1 child on the left

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the node from the AVL
                return node.getLeft();
            } else {
                //Getting the data from the predecessor
                Object newData = getSuccessorHelper(node.getRight());

                //Removing the node containing the predecessor from the tree
                removeHelper((T) newData, node, dummy);

                //Saving the removed data in the dummy node
                dummy.setData(node.getData());

                //Removing the data from the AVL (by setting its data to that of the predecessor)
                node.setData((T) newData);
                return node;
            }
        } else if (data.compareTo(node.getData()) > 0) {
            //Go right if the data to be entered is greater than the node's data
            node.setRight(removeHelper(data, node.getRight(), dummy));
        } else if (data.compareTo(node.getData()) < 0) {
            //Go left if the data to be entered is less than the node's data
            node.setLeft(removeHelper(data, node.getLeft(), dummy));
        }
        //Do the rotations if needed

        node.setHeight(Math.max(nodeHeight(node.getLeft()), nodeHeight(node.getRight())) + 1);

        node.setBalanceFactor(nodeBalance(node));

        if (node.getBalanceFactor() == -2 && node.getRight().getBalanceFactor() <= 0) {
            return leftRotate(node);
        } else if (node.getBalanceFactor() == 2 && node.getLeft().getBalanceFactor() >= 0) {
            return rightRotate(node);
        } else if (node.getBalanceFactor() == 2 && node.getLeft().getBalanceFactor() < 0) {
            node.setLeft(leftRotate(node.getLeft()));
            return rightRotate(node);
        } else if (node.getBalanceFactor() == -2 && node.getRight().getBalanceFactor() > 0) {
            node.setRight(rightRotate(node.getRight()));
            return leftRotate(node);
        }

        return node;
    }

    /**
     * Helper function for finding the successor of a node
     *
     * @param node the left child of the node whose successor is meant to be found
     * @return the data of the successor of the inputted node's parent
     */
    private T getSuccessorHelper(AVLNode<T> node) {
        //Keeps going right until you find the right-most node in the subtree

        //Base Case:
        if (node.getLeft() == null) {
            return node.getData();
        }
        return getSuccessorHelper(node.getLeft());
    }

    /**
     * Returns the element from the tree matching the given parameter.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the tree.
     *
     * @param data the data to search for in the tree
     * @return the data in the tree equal to the parameter
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not in the tree
     */
    public T get(T data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException("The data entered is null! Cannot search for null in the tree.");
        }
        //Getting the node with the data
        AVLNode<T> node = getHelper(data, root);

        //Exception:
        if (node == null) {
            throw new NoSuchElementException("The data is not found in the list!");
        } else {
            return node.getData();
        }
    }

    /**
     * Recursive helper function for get.
     *
     * @param data the data that is being looked for in the list.
     * @param node the node where the node where the data is being looked for
     * @return the node where the data is found if the tree contains the data, null if not
     */
    private AVLNode<T> getHelper(T data, AVLNode<T> node) {
        //Performs recursive binary search to find the node with the given data

        if (node == null) {
            return null;
        } else if (data.compareTo(node.getData()) > 0) {
            return getHelper(data, node.getRight());
        } else if (data.compareTo(node.getData()) < 0) {
            return getHelper(data, node.getLeft());
        } else {
            return node;
        }

    }

    /**
     * Returns whether or not data matching the given parameter is contained
     * within the tree.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * @param data the data to search for in the tree.
     * @return true if the parameter is contained within the tree, false
     * otherwise
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public boolean contains(T data) {
        //Exception:
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is nulL! Cannot search for null in the AVL.");
        }
        //Call the helper function
        return containsHelper(data, root);
    }

    /**
     * Recursive helper function for contains
     *
     * @param data the data that is being looked for in the list.
     * @param node the node where the node where the data is being looked for
     * @return true if the parameter is contained within the tree, false
     * otherwise
     */
    private boolean containsHelper(T data, AVLNode<T> node) {
        //Performs recursive binary search to find if the AVL contains the data
        if (node == null) {
            return false;
        } else if (data.compareTo(node.getData()) > 0) {
            return containsHelper(data, node.getRight());
        } else if (data.compareTo(node.getData()) < 0) {
            return containsHelper(data, node.getLeft());
        } else {
            return true;
        }
    }

    /**
     * Returns the height of the root of the tree.
     *
     * @return the height of the root of the tree, -1 if the tree is empty
     */
    public int height() {
        if (size == 0) {
            return -1;
        }
        return root.getHeight();
    }

    /**
     * Clears the tree.
     *
     * Clears all data and resets the size.
     */
    public void clear() {
        root = null;
        size = 0;
    }

    /**
     * Returns the data in the deepest node. If there is more than one node
     * with the same deepest depth, return the rightmost (i.e. largest) node with 
     * the deepest depth. 
     *
     * Must run in O(log n) for all cases.
     *
     * Example
     * Tree:
     *           2
     *        /    \
     *       0      3
     *        \
     *         1
     * Max Deepest Node:
     * 1 because it is the deepest node
     *
     * Example
     * Tree:
     *           2
     *        /    \
     *       0      4
     *        \    /
     *         1  3
     * Max Deepest Node:
     * 3 because it is the maximum deepest node (1 has the same depth but 3 > 1)
     *
     * @return the data in the maximum deepest node or null if the tree is empty
     */
    public T maxDeepestNode() {
        if (size == 0) {
            return null;
        }
        AVLNode<T> dummyData = new AVLNode<>(root.getData());
        AVLNode<Integer> dummyDeepestDepth = new AVLNode<>(0);
        AVLNode<Integer> dummyCurrentDepth = new AVLNode<>(0);
        maxDeepestNodeHelper(root, dummyData, dummyDeepestDepth, dummyCurrentDepth);
        return dummyData.getData();
    }

    /**
     * Helper function for maxDeppestNode
     *
     * @param node the node where we are performing the comparison
     * @param dummyData the data which will be returned at the end
     * @param dummyCurrentDepth the current depth of the node we are looking at
     * @param dummyDeepestDepth the depth of the node whose data we are returning
     */
    private void maxDeepestNodeHelper(AVLNode<T> node, AVLNode<T> dummyData, AVLNode<Integer> dummyCurrentDepth,
                                   AVLNode<Integer> dummyDeepestDepth) {
        if (node == null) {
            dummyCurrentDepth.setData(dummyCurrentDepth.getData() - 1);
            return;
        }
        dummyCurrentDepth.setData(dummyCurrentDepth.getData() + 1);
        maxDeepestNodeHelper(node.getLeft(), dummyData, dummyCurrentDepth, dummyDeepestDepth);
        dummyCurrentDepth.setData(dummyCurrentDepth.getData() + 1);
        maxDeepestNodeHelper(node.getRight(), dummyData, dummyCurrentDepth, dummyDeepestDepth);

        if (dummyCurrentDepth.getData().compareTo(dummyDeepestDepth.getData()) > 0) {
            dummyDeepestDepth.setData(dummyCurrentDepth.getData());
            dummyData.setData(node.getData());
        }
        if (dummyCurrentDepth.getData().equals(dummyDeepestDepth.getData())
            && node.getData().compareTo(dummyData.getData()) > 0) {
            dummyData.setData(node.getData());
        }
        dummyCurrentDepth.setData(dummyCurrentDepth.getData() - 1);
    }


    /**
     * In BSTs, you learned about the concept of the successor: the
     * smallest data that is larger than the current data. However, you only
     * saw it in the context of the 2-child remove case.
     *
     * This method should retrieve (but not remove) the successor of the data
     * passed in. There are 2 cases to consider:
     * 1: The right subtree is non-empty. In this case, the successor is the
     * leftmost node of the right subtree.
     * 2: The right subtree is empty. In this case, the successor is the lowest
     * ancestor of the node containing data whose left child is also
     * an ancestor of data.
     * 
     * The second case means the successor node will be one of the node(s) we 
     * traversed left from to find data. Since the successor is the SMALLEST element 
     * greater than data, the successor node is the lowest/last node 
     * we traversed left from on the path to the data node.
     *
     * This should NOT be used in the remove method.
     *
     * Ex:
     * Given the following AVL composed of Integers
     *                    76
     *                  /    \
     *                34      90
     *                  \    /
     *                  40  81
     * successor(76) should return 81
     * successor(81) should return 90
     * successor(40) should return 76
     *
     * @param data the data to find the successor of
     * @return the successor of data. If there is no larger data than the
     * one given, return null.
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not in the tree
     */
    public T successor(T data) {
        if (data == null) {
            throw new IllegalArgumentException("The data you entered is null! Cannot look for the successor of null.");
        }
        if (size == 0) {
            throw new NoSuchElementException("The AVL is empty! There are no successors in an empty tree!");
        }

        Object answer = successorHelper(data, root, new AVLNode<T>(root.getData()));

        if (((T) answer).compareTo(data) > 0) {
            return (T) answer;
        } else {
            return null;
        }
    }

    /**
     * Helper function which gets the successor
     *
     * @param data the data whose successor we are finding
     * @param node the current node where we are searching
     * @param dummy the dummy node which will store the successor
     * @return the successor of the data
     */

    private T successorHelper(T data, AVLNode<T> node, AVLNode<T> dummy) {
        if (node == null) {
            throw new NoSuchElementException("The tree doesn't contain the data given!");
        }
        if (data.compareTo(node.getData()) > 0) {
            return successorHelper(data, node.getRight(), dummy);
        } else if (data.compareTo(node.getData()) < 0) {
            dummy.setData(node.getData());
            return successorHelper(data, node.getLeft(), dummy);
        } else {
            if (node.getRight() == null) {
                return dummy.getData();
            } else {
                return getSuccessorHelper(node.getRight());
            }
        }

    }

    /**
     * Returns the root of the tree.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the root of the tree
     */
    public AVLNode<T> getRoot() {
        // DO NOT MODIFY THIS METHOD!
        return root;
    }

    /**
     * Returns the size of the tree.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the size of the tree
     */
    public int size() {
        // DO NOT MODIFY THIS METHOD!
        return size;
    }
}
